@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form  action="{{route('eventstore') }}" method="post">

                    @csrf


                    <label for="fname">Event Title:</label><br>
                    <input type="text" id="title" name="title" ><br><br>
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('title') }}</span>
                @endif

                    <label for="fname">Start Date:</label><br>
                    <input type="date" id="start" name="start" ><br><br>
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('start') }}</span>
                @endif

                    <label for="fname">End Date Date:</label><br>
                    <input type="date" id="end" name="end"><br><br>
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('end') }}</span>
                @endif

                    <label for="cars">Choose :</label>
                    <select name="repeat" id="repeat">
                    <option value="1">No Repeat</option>
                    <option value="2">Daily</option>
                    <option value="3">Alternate Day</option>
                    <option value="4">Weekly</option>
                    <option value="5">Monthly</option>
                    <option value="6">Yearly</option>
                    </select>
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('repeat') }}</span>
                @endif

                    <label for="desc">Description:</label>
                    <textarea id="desc" name="desc" rows="4" cols="50">
                    </textarea>
                    @if ($errors->has('name'))
                    <span class="text-danger">{{ $errors->first('desc') }}</span>
                @endif

                    <input type="submit" value="Submit">
                    </form> 


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
