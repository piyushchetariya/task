@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <a href="{{route('addevent')}}" ><button style="float: right;" class="button">Add Event</button></a>
                    <table>
                    <tr>
                        <th>Title</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Repeat</th>
                        <th>Description</th>
                        <th>Delete</th>

                        

                    </tr>
                    @if(!empty($event) && $event->count())
                    @foreach($event as $a)
                    <tr>
                        <td>{{$a->title}}</td>
                        <td>{{$a->start}}</td>
                        <td>{{$a->end}}</td>
                        <td>{{$a->repeat}}</td>
                        <td>{{$a->desc}}</td>
                        <td><a href="{{route('delete',$a->id)}}">Delete</a></td>


                    </tr>
                    @endforeach
            
        @else
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        @endif
                    
                        </table>
                    {!! $event->links() !!}

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
