<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form  action="<?php echo e(route('eventstore')); ?>" method="post">

                    <?php echo csrf_field(); ?>


                    <label for="fname">Event Title:</label><br>
                    <input type="text" id="title" name="title" ><br><br>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>

                    <label for="fname">Start Date:</label><br>
                    <input type="date" id="start" name="start" ><br><br>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('start')); ?></span>
                <?php endif; ?>

                    <label for="fname">End Date Date:</label><br>
                    <input type="date" id="end" name="end"><br><br>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('end')); ?></span>
                <?php endif; ?>

                    <label for="cars">Choose :</label>
                    <select name="repeat" id="repeat">
                    <option value="1">No Repeat</option>
                    <option value="2">Daily</option>
                    <option value="3">Alternate Day</option>
                    <option value="4">Weekly</option>
                    <option value="5">Monthly</option>
                    <option value="6">Yearly</option>
                    </select>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('repeat')); ?></span>
                <?php endif; ?>

                    <label for="desc">Description:</label>
                    <textarea id="desc" name="desc" rows="4" cols="50">
                    </textarea>
                    <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('desc')); ?></span>
                <?php endif; ?>

                    <input type="submit" value="Submit">
                    </form> 


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/piyushchetariya/Desktop/untitled folder/task/resources/views/addevent.blade.php ENDPATH**/ ?>