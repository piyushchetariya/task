<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('addevent')); ?>" ><button style="float: right;" class="button">Add Event</button></a>
                    <table>
                    <tr>
                        <th>Title</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Repeat</th>
                        <th>Description</th>
                        <th>Delete</th>

                        

                    </tr>
                    <?php if(!empty($event) && $event->count()): ?>
                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($a->title); ?></td>
                        <td><?php echo e($a->start); ?></td>
                        <td><?php echo e($a->end); ?></td>
                        <td><?php echo e($a->repeat); ?></td>
                        <td><?php echo e($a->desc); ?></td>
                        <td><a href="<?php echo e(route('delete',$a->id)); ?>">Delete</a></td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        <?php else: ?>
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        <?php endif; ?>
                    
                        </table>
                    <?php echo $event->links(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/piyushchetariya/Desktop/untitled folder/task/resources/views/home.blade.php ENDPATH**/ ?>