<?php

namespace App\Http\Controllers;
use App\Models\event;
use App\Http\Requests\eventstore;
use DateTime;



use Illuminate\Support\Facades\Validator;
use Session;


use Illuminate\Http\Request;

class EventController extends Controller
{
    public function add()
    {
        return view('addevent');
    }
    public function store(eventstore $request)
    {
        
            $validator = Validator::make($request->all(), [
                'title' => 'required',
                'start' => 'required',
                'end' => 'required',
                'repeat' => 'required',
                'desc' => 'required'   
            ]);
             
            if ($validator->fails()) {
                 Session::flash('error', $validator->messages()->first());
                 return redirect()->back()->withInput();
            }
            
            try{
            
                if($request->get('repeat') == '1')
            {
               $event = new event;
               $event->title = $request->get('title');
               $event->start =  $request->get('start');
               $event->end =  $request->get('end');
               $event->repeat =	 $request->get('repeat');
               $event->desc =  $request->get('desc');
               $event->save();
               return redirect()->route('home');

            }
            elseif($request->get('repeat') == '2')
            {
                $date1 = new DateTime($request->get('start'));
                $date2 = new DateTime($request->get('end'));
                $interval = $date1->diff($date2);
                $diff = $interval->format('%d');
                
                for ($x = 0; $x <= $diff; $x++) {
                    $event = new event;
                        $event->title = $request->get('title');
                        $event->start =  $request->get('start');
                        $event->end =  $request->get('end');
                        $event->repeat =	 $request->get('repeat');
                        $event->desc =  $request->get('desc');
                        $event->save(); 
                  }
                  return redirect()->route('home');

            }
            elseif($request->get('repeat') == '3')
            {
                $date1 = new DateTime($request->get('start'));
                $date2 = new DateTime($request->get('end'));
                $interval = $date1->diff($date2);
                $diff = $interval->format('%d');
                
                for ($x = 0; $x <= $diff/2; $x++) {
                    $event = new event;
                        $event->title = $request->get('title');
                        $event->start =  $request->get('start');
                        $event->end =  $request->get('end');
                        $event->repeat =	 $request->get('repeat');
                        $event->desc =  $request->get('desc');
                        $event->save(); 
                  }
                  return redirect()->route('home');
            }
            elseif($request->get('repeat') == '4')
            {
                $date1 = new DateTime($request->get('start'));
                $date2 = new DateTime($request->get('end'));
                $interval = $date1->diff($date2);
                $diff = $interval->format('%d');
                
                for ($x = 0; $x <= $diff/2; $x++) {
                    $event = new event;
                        $event->title = $request->get('title');
                        $event->start =  $request->get('start');
                        $event->end =  $request->get('end');
                        $event->repeat =	 $request->get('repeat');
                        $event->desc =  $request->get('desc');
                        $event->save(); 
                  }
                  return redirect()->route('home');                
            }
            elseif($request->get('repeat') == '5')
            {
                
                
                echo('5');  
            }
            elseif($request->get('repeat') == '6')
            {
                
                
                echo('6');  
            }
                
               //return redirect()->route('home');

        }
        catch (Throwable $e) {
            report($e);
    
            return false;
        }
       
       

    }
    public function delete($id)
    {
        try {

        $event = event::find($id);
        $event->delete();  
        return redirect()->route('home');

        } catch (Throwable $e) {
            report($e);
    
            return false;
        }
        
    }
}
